# Code for the BCSS tutorial on using JAGS for wildlife data analysis
# https://bcss.org.my/tut/bayes-with-jags-a-tutorial-for-wildlife-researchers/abundance-from-capture-recapture-data/data-augmentation-and-abundance-estimates/
# Author: Mike Meredith
# License: GPL 3
# ----------------------------------------------------------------------------

# Closed captures - Kanha tigers - using data augmentation

# Using the 'nimble' package instead of JAGS

library(nimble)
library(wiqid)

tigs <- read.csv("http://bcss.org.my/data/Kanha_tigers.csv", comment="#", header=FALSE)
# If not online but have the CSV file in working directory:
# tigs <- read.csv("Kanha_tigers.csv", comment="#", header=FALSE)

str(tigs)
summary(tigs)

wiqid::closedCapM0(tigs)

# For the M0 model, we can aggregate the captures
( y <- rowSums(tigs) )

# Data augmentation
# -----------------
# Augment the observed captures with all-zero capture histories
naug <- 30
yaug <- c(y, rep(0, naug))
( M <- length(yaug) )

# Write the model for NIMBLE
closedCaptures.code <- nimbleCode({
  # Likelihood
  for(i in 1:M) {
     # Ecological model
     w[i] ~ dbern(omega)  # w=1 if present, w=0 if absent/phantom
     # Observation model
     y[i] ~ dbin(p * w[i], n)
  }

  # Uninformative uniform priors
  p ~ dbeta(1, 1)
  omega ~ dbeta(s1, s2)  # specify s1 and s2 in the input

  # Derived values
  N <- sum(w[1:M])
})

# Organise the data etc
nimData <- list(y = yaug, w = ifelse(yaug > 0, 1, NA))
str(nimData)
nimConst <- list(n = 10, M = M, s1 = 1, s2 = 1)

wanted <- c("p", "omega", "N")

system.time(
out1 <- nimbleMCMC(closedCaptures.code, nimConst, nimData, monitors=wanted,
    nchains=3, niter=11e3, nburnin=1e3, samplesAsCodaMCMC=TRUE) ) # 20 secs
diagPlot(out1)

( mco1 <- mcmcOutput(out1) )
summary(mco1)
#         mean    sd median    l95    u95  Rhat MCEpc
# N     29.567 2.473 29.000 26.000 34.000 1.000 1.201
# omega  0.527 0.077  0.526  0.377  0.678 1.000 0.955
# p      0.199 0.028  0.198  0.145  0.252 0.998 1.563

plot(mco1)

# Explore informative prior
# -------------------------
library(wiqid)

# Maximum plausible value
M <- 100
# Prior mode for N and omega
Nmode <- 20
omegaMode <- Nmode/M
# Range of values for N and omega
N <- 0:M
omega <- N/M

# Do the plots
par(mfrow=c(1,3))
pN3 <- dbeta3(omega, Nmode/M, 3)/M
plot(N, pN3, main="mode=20, concentration=3")
pN4 <- dbeta3(omega, Nmode/M, 4)/M
plot(N, pN4, main="mode=20, concentration=4")
pN5 <- dbeta3(omega, Nmode/M, 5)/M
plot(N, pN5, main="mode=20, concentration=5")
par(mfrow=c(1,1))

# Get shape parameters for use in NIMBLE
( pars <- getBeta3Par(Nmode/M, 5) )
#      shape1 shape2
# [1,]    1.6    3.4

# NIMBLE analysis with weakly informative prior
# ---------------------------------------------

# Organise the data etc
naug <- M - length(y)
yaug <- c(y, rep(0, naug))
nimData <- list(y = yaug, w = ifelse(yaug > 0, 1, NA))
str(nimData)
nimConst <- list(n = 10, M = M, s1 = pars[1], s2 = pars[2])

system.time(
out2 <- nimbleMCMC(closedCaptures.code, nimConst, nimData, monitors=wanted,
    nchains=3, niter=11e3, nburnin=1e3, samplesAsCodaMCMC=TRUE) ) # 22 secs
diagPlot(out2)

( mco2 <- mcmcOutput(out2) )
summary(mco2)
plot(mco2)
