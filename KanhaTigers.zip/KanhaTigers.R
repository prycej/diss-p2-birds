# Code for the BCSS tutorial on using JAGS for wildlife data analysis
# https://bcss.org.my/tut/bayes-with-jags-a-tutorial-for-wildlife-researchers/abundance-from-capture-recapture-data/data-augmentation-and-abundance-estimates/
# Author: Mike Meredith
# License: GPL 3
# ----------------------------------------------------------------------------

# Closed captures - Kanha tigers - using data augmentation

library(jagsUI)
library(wiqid)

tigs <- read.csv("http://bcss.org.my/data/Kanha_tigers.csv", comment="#", header=FALSE)
# If not online but have the CSV file in working directory:
tigs <- read.csv("Kanha_tigers.csv", comment="#", header=FALSE)

str(tigs)
summary(tigs)

wiqid::closedCapM0(tigs)

# For the M0 model, we can aggregate the captures
( y <- rowSums(tigs) )

# Run JAGS analysis
# -----------------
# Augment the observed captures with all-zero capture histories
naug <- 30
yaug <- c(y, rep(0, naug))
( M <- length(yaug) )

# Organise the data etc
jagsData <- list(y = yaug, n = 10, M = M, w = ifelse(yaug > 0, 1, NA))
str(jagsData)

wanted <- c("p", "omega", "N")

set.seed(1)  # Use this to get the same output as the web page
( outM0 <- jags(jagsData, NULL, wanted,
  model="closedCaptures.jags", DIC=FALSE,
  n.chains=3, n.iter=20000, n.thin=2) )
  # Takes < 5 secs
#         mean    sd   2.5%    50%  97.5% overlap0 f Rhat n.eff
# p      0.200 0.028  0.148  0.199  0.256    FALSE 1    1 30000
# omega  0.527 0.077  0.379  0.525  0.682    FALSE 1    1 14374
# N     29.519 2.455 26.000 29.000 35.000    FALSE 1    1 17947

# Convert to Bwiqid class and plot
library(wiqid)
outB <- as.Bwiqid(outM0, default='N')
diagPlot(outB)
plot(outB)
plot(outB, 'omega', showCurve=TRUE)

# Explore informative prior
# -------------------------
library(wiqid)

# Maximum plausible value
M <- 100
# Prior mode for N and omega
Nmode <- 20
omegaMode <- Nmode/M
# Range of values for N and omega
N <- 0:M
omega <- N/M

# Do the plots
par(mfrow=c(1,3))
pN3 <- dbeta3(omega, Nmode/M, 3)/M
plot(N, pN3, main="mode=20, concentration=3")
pN4 <- dbeta3(omega, Nmode/M, 4)/M
plot(N, pN4, main="mode=20, concentration=4")
pN5 <- dbeta3(omega, Nmode/M, 5)/M
plot(N, pN5, main="mode=20, concentration=5")
par(mfrow=c(1,1))

# Get shape parameters for use in JAGS
( pars <- getBeta3Par(Nmode/M, 5) )
#      shape1 shape2
# [1,]    1.6    3.4

# JAGS analysis with weakly informative prior
# -------------------------------------------
naug <- M - length(y)
yaug <- c(y, rep(0, naug))

# Organise the data etc
jagsData <- list(y = yaug, n = 10, M = M, w = ifelse(yaug > 0, 1, NA))
str(jagsData)

wanted <- c("p", "omega", "N")

set.seed(1)
( outM0inf <- jags(jagsData, NULL, wanted,
    model="closedCaptures_infoPrior.jags", DIC=FALSE,
    n.chains=3, n.iter=20000, n.thin=2) )
  # Takes < 5 secs
diagPlot(outM0inf)

outBinf <- as.Bwiqid(outM0inf, default='N')
plot(outBinf)
